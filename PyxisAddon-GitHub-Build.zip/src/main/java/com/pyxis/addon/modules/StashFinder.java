package com.pyxis.addon.modules;

import com.pyxis.addon.PyxisAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class StashFinder extends Module {
    private static final Path LOG_FILE = FabricLoader.getInstance().getGameDir().resolve("pyxis-stash-finder.log");
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final HttpClient HTTP = HttpClient.newHttpClient();

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> scanDelay = sgGeneral.add(new IntSetting.Builder()
        .name("scan-delay").description("Ticks between scan cycles.")
        .defaultValue(40).min(10).sliderMax(200).build());

    private final Setting<Integer> chunksPerTick = sgGeneral.add(new IntSetting.Builder()
        .name("chunks-per-tick").description("Loaded chunks processed per tick.")
        .defaultValue(2).min(1).sliderMax(8).build());

    private final Setting<Integer> yRange = sgGeneral.add(new IntSetting.Builder()
        .name("y-range").description("Vertical scan range around your position.")
        .defaultValue(32).min(8).sliderMax(128).build());

    private final Setting<Integer> clusterRadius = sgGeneral.add(new IntSetting.Builder()
        .name("cluster-radius").description("Maximum horizontal/vertical grouping distance.")
        .defaultValue(12).min(2).sliderMax(32).build());

    private final Setting<Integer> minBlocks = sgGeneral.add(new IntSetting.Builder()
        .name("min-blocks").description("Minimum matching blocks before an alert.")
        .defaultValue(3).min(1).sliderMax(20).build());

    private final Setting<Set<Block>> blocks = sgGeneral.add(new BlockListSetting.Builder()
        .name("blocks").description("Blocks counted by the scanner.")
        .defaultValue(
            Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL,
            Blocks.SHULKER_BOX, Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX,
            Blocks.MAGENTA_SHULKER_BOX, Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX,
            Blocks.LIME_SHULKER_BOX, Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX,
            Blocks.LIGHT_GRAY_SHULKER_BOX, Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX,
            Blocks.BLUE_SHULKER_BOX, Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX,
            Blocks.RED_SHULKER_BOX, Blocks.BLACK_SHULKER_BOX,
            Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER,
            Blocks.CRAFTING_TABLE, Blocks.ENDER_CHEST,
            Blocks.LODESTONE, Blocks.RESPAWN_ANCHOR, Blocks.BEACON,
            Blocks.ENCHANTING_TABLE, Blocks.JUKEBOX, Blocks.NOTE_BLOCK,
            Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL,
            Blocks.BREWING_STAND, Blocks.HOPPER, Blocks.DROPPER,
            Blocks.OBSERVER, Blocks.PISTON, Blocks.STICKY_PISTON
        ).build());

    private final Setting<Boolean> chatAlerts = sgGeneral.add(new BoolSetting.Builder()
        .name("chat-alerts").description("Notify in chat.").defaultValue(true).build());

    private final Setting<Boolean> sound = sgGeneral.add(new BoolSetting.Builder()
        .name("sound").description("Play a sound when a cluster is first detected.").defaultValue(true).build());

    private final Setting<Boolean> logToFile = sgGeneral.add(new BoolSetting.Builder()
        .name("log-to-file").description("Append detections to pyxis-stash-finder.log.").defaultValue(true).build());

    private final Setting<String> webhookUrl = sgGeneral.add(new StringSetting.Builder()
        .name("webhook-url").description("Optional Discord webhook URL; leave blank to disable.")
        .defaultValue("").build());

    private final Setting<Boolean> showRender = sgRender.add(new BoolSetting.Builder()
        .name("show").description("Render outlines around detected blocks.").defaultValue(true).build());

    private final Setting<Integer> maxRenderBlocks = sgRender.add(new IntSetting.Builder()
        .name("max-render-blocks").description("Maximum rendered block count.")
        .defaultValue(1000).min(100).sliderMax(5000).build());

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color").defaultValue(new SettingColor(255, 60, 60, 30)).build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color").defaultValue(new SettingColor(255, 60, 60, 200)).build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode").defaultValue(ShapeMode.Both).build());

    private final Deque<ChunkPos> scanQueue = new ArrayDeque<>();
    private final Set<Long> queuedChunks = new HashSet<>();
    private final Map<String, Stash> stashes = new LinkedHashMap<>();
    private final Set<BlockPos> countedBlocks = new HashSet<>();
    private final Set<String> alerted = new HashSet<>();
    private int delayLeft;

    private static final class Stash {
        final List<BlockPos> blocks = new ArrayList<>();
        long sumX, sumY, sumZ;
        long lastSeen;
        boolean alerted;

        void add(BlockPos pos) {
            blocks.add(pos);
            sumX += pos.getX();
            sumY += pos.getY();
            sumZ += pos.getZ();
            lastSeen = System.currentTimeMillis();
        }

        BlockPos center() {
            return new BlockPos((int) (sumX / blocks.size()), (int) (sumY / blocks.size()), (int) (sumZ / blocks.size()));
        }
    }

    public StashFinder() {
        super(PyxisAddon.CATEGORY, "stash-finder", "Scans loaded client chunks for configured block clusters.");
    }

    @Override
    public void onActivate() {
        stashes.clear();
        countedBlocks.clear();
        alerted.clear();
        scanQueue.clear();
        queuedChunks.clear();
        delayLeft = 0;
    }

    @Override
    public void onDeactivate() {
        scanQueue.clear();
        queuedChunks.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.world == null) return;

        if (scanQueue.isEmpty()) {
            if (delayLeft <= 0) {
                queueChunksAroundPlayer();
                delayLeft = scanDelay.get();
            } else {
                delayLeft--;
            }
        }

        int done = 0;
        while (done < chunksPerTick.get() && !scanQueue.isEmpty()) {
            ChunkPos cp = scanQueue.poll();
            queuedChunks.remove(ChunkPos.toLong(cp.x, cp.z));
            scanChunk(cp);
            done++;
        }

        long now = System.currentTimeMillis();
        stashes.values().removeIf(s -> now - s.lastSeen > 30 * 60 * 1000L);
    }

    private void queueChunksAroundPlayer() {
        ChunkPos center = new ChunkPos(mc.player.getBlockPos());
        int radius = mc.options.getViewDistance().getValue();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                ChunkPos cp = new ChunkPos(center.x + dx, center.z + dz);
                long key = ChunkPos.toLong(cp.x, cp.z);
                if (queuedChunks.add(key)) scanQueue.add(cp);
            }
        }
    }

    private void scanChunk(ChunkPos cp) {
        if (!mc.world.getChunkManager().isChunkLoaded(cp.x, cp.z)) return;

        int minY = Math.max(mc.world.getBottomY(), mc.player.getBlockY() - yRange.get());
        int maxY = Math.min(mc.world.getTopYInclusive(), mc.player.getBlockY() + yRange.get());

        for (BlockPos pos : BlockPos.iterate(cp.getStartX(), minY, cp.getStartZ(), cp.getEndX(), maxY, cp.getEndZ())) {
            Block block = mc.world.getBlockState(pos).getBlock();
            if (blocks.get().contains(block)) addBlock(pos.toImmutable());
        }
    }

    private void addBlock(BlockPos pos) {
        if (!countedBlocks.add(pos)) return;

        int radius = clusterRadius.get();
        Stash nearest = null;
        double nearestDistance = Double.MAX_VALUE;

        for (Stash stash : stashes.values()) {
            BlockPos center = stash.center();
            int dx = Math.abs(center.getX() - pos.getX());
            int dy = Math.abs(center.getY() - pos.getY());
            int dz = Math.abs(center.getZ() - pos.getZ());
            if (dx <= radius && dz <= radius && dy <= radius * 2) {
                double distance = (double) dx * dx + (double) dy * dy + (double) dz * dz;
                if (distance < nearestDistance) {
                    nearestDistance = distance;
                    nearest = stash;
                }
            }
        }

        if (nearest == null) {
            nearest = new Stash();
            nearest.add(pos);
            stashes.put(UUID.randomUUID().toString(), nearest);
        } else {
            nearest.add(pos);
        }

        if (nearest.blocks.size() >= minBlocks.get() && !nearest.alerted) {
            nearest.alerted = true;
            alert(nearest);
        }
    }

    private void alert(Stash stash) {
        String dim = mc.world.getRegistryKey().getValue().toString();
        BlockPos c = stash.center();
        String coords = c.getX() + " " + c.getY() + " " + c.getZ();
        String msg = "STASH FOUND | " + dim + " | " + coords + " | " + stash.blocks.size()
            + " blocks | " + TIME.format(LocalDateTime.now());

        if (chatAlerts.get()) info("New stash: %s (%s), %d blocks", coords, dim, stash.blocks.size());
        if (sound.get()) mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.5f));
        if (logToFile.get()) writeLog(msg);
        sendWebhook(msg);
    }

    private void writeLog(String line) {
        try {
            Files.writeString(LOG_FILE, line + System.lineSeparator(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            error("Could not write log: %s", e.getMessage());
        }
    }

    private void sendWebhook(String content) {
        String url = webhookUrl.get().trim();
        if (url.isEmpty()) return;

        try {
            URI uri = URI.create(url);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) {
                error("Webhook URL must be a valid HTTPS URL.");
                return;
            }
            String json = "{\"content\":\"" + content.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r") + "\"}";
            HttpRequest request = HttpRequest.newBuilder(uri)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

            HTTP.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .exceptionally(e -> {
                    error("Webhook error: %s", e.getMessage());
                    return null;
                });
        } catch (IllegalArgumentException e) {
            error("Invalid webhook URL.");
        }
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!showRender.get()) return;
        int rendered = 0;
        for (Stash stash : stashes.values()) {
            for (BlockPos pos : stash.blocks) {
                if (rendered >= maxRenderBlocks.get()) return;
                event.renderer.box(new Box(pos), sideColor.get(), lineColor.get(), shapeMode.get(), null);
                rendered++;
            }
        }
    }
}
