package com.pyxis.addon.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.command.CommandSource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;
import static com.mojang.brigadier.builder.LiteralArgumentBuilder.literal;

public class StashCommand extends Command {
    private static final Path LOG_FILE = FabricLoader.getInstance().getGameDir().resolve("pyxis-stash-finder.log");

    public StashCommand() {
        super("stash", "View or clear the Pyxis stash detection log.", "stashes");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> {
            list();
            return SINGLE_SUCCESS;
        });

        builder.then(literal("clear").executes(context -> {
            try {
                Files.deleteIfExists(LOG_FILE);
                info("Log cleared.");
            } catch (IOException e) {
                error("Could not clear log: %s", e.getMessage());
            }
            return SINGLE_SUCCESS;
        }));
    }

    private void list() {
        if (!Files.exists(LOG_FILE)) {
            info("No detections in the log yet.");
            return;
        }

        try {
            List<String> lines = Files.readAllLines(LOG_FILE);
            int count = Math.min(lines.size(), 15);
            info("--- Latest %d detections (total %d) ---", count, lines.size());
            for (int i = lines.size() - count; i < lines.size(); i++) info(lines.get(i));
        } catch (IOException e) {
            error("Could not read log: %s", e.getMessage());
        }
    }
}
