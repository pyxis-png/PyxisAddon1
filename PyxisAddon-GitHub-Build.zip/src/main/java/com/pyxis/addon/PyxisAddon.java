package com.pyxis.addon;

import com.pyxis.addon.commands.StashCommand;
import com.pyxis.addon.modules.StashFinder;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.commands.Commands;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Modules;

public class PyxisAddon extends MeteorAddon {
    public static final Category CATEGORY = new Category("Pyxis");

    @Override
    public void onInitialize() {
        Modules.get().add(new StashFinder());
        Commands.add(new StashCommand());
    }

    @Override
    public void onRegisterCategories() {
        Categories.register(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.pyxis.addon";
    }
}
