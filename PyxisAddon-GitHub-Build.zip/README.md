# PyxisAddon

A Meteor Client addon project for Minecraft **1.21.11**.

## Features

- `stash-finder` module: scans client-loaded chunks for blocks in its configurable block list.
- Groups nearby matching blocks and highlights detected clusters.
- Optional chat alert, sound, local log, and HTTPS Discord webhook.
- `.stash` / `.stashes`: prints the latest 15 log entries.
- `.stash clear`: deletes the local detection log.

## Requirements

- Minecraft 1.21.11
- Fabric Loader
- Meteor Client build for Minecraft 1.21.11
- Java 21
- Gradle 8.14.3 (to generate the wrapper if needed)

## Build

If Gradle is installed, generate the wrapper once:

```bash
gradle wrapper --gradle-version 8.14.3
```

Then build:

```bash
./gradlew build
```

Windows:

```bat
gradlew.bat build
```

The addon JAR is created in `build/libs/`.

## Install

Put the generated `PyxisAddon-1.0.0.jar` into the Fabric `mods` folder alongside the matching Meteor Client JAR.

## Notes

- The scanner only inspects chunks already loaded by the client; it does not request or force-load remote chunks.
- Each block position is counted once per activation, so repeated scans do not inflate cluster counts.
- A cluster triggers at most one alert during a module activation.
- The log is saved as `pyxis-stash-finder.log` in the Minecraft game directory.
- Webhook is optional. Keep your webhook URL private and use only one you control.
- This source package has not been compiled in this environment. If Gradle reports a dependency/API mismatch, check the Meteor 1.21.11 template and matching Maven artifact before changing the Java source.
